/* EXP 4  I2C1 slave, own address 0x28  ---  SLAVE  ---  NUCLEO-F446RE
 * OAR1 bit 14 must be written as 1, and ACK must be set AFTER PE = 1.
 * A slave programs no CCR: the master supplies SCL.
 * Wiring : PB8 SCL (CN10-3), PB9 SDA (CN10-5), GND (CN10-20)
 *          + one 4.7k pull-up on each line to +3V3 (CN7-16).          */

#include "stm32f446xx.h"

#define WAIT(c) { uint32_t w = 200000; while (!(c) && --w); }

static void delay_ms(uint32_t ms)
{
    SysTick->LOAD = 16000 - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;
    while (ms--) while (!(SysTick->CTRL & (1 << 16)));
    SysTick->CTRL = 0;
}

static void blink(uint32_t d)
{
    for (int i = 0; i < 3; i++) {
        GPIOA->ODR |=  (1 << 5);  delay_ms(d);
        GPIOA->ODR &= ~(1 << 5);  delay_ms(d);
    }
}

int main(void)
{
    uint8_t c;

    RCC->AHB1ENR |= (1 << 0) | (1 << 1);        /* GPIOA, GPIOB         */
    RCC->APB1ENR |= (1 << 21);                  /* I2C1                 */

    GPIOA->MODER  |= (1 << 10);                 /* PA5 output    (LD2)  */
    GPIOB->MODER  |= (2 << 16) | (2 << 18);     /* PB8, PB9 alternate   */
    GPIOB->OTYPER |= (1 << 8) | (1 << 9);       /* OPEN DRAIN           */
    GPIOB->AFR[1] |= (4 << 0) | (4 << 4);       /* AF4 = I2C1           */

    I2C1->CR2  = 16;                            /* PCLK1 = 16 MHz       */
    I2C1->OAR1 = (0x28 << 1) | (1 << 14);       /* own address, bit14=1 */
    I2C1->CR1  = 1;                             /* PE                   */
    I2C1->CR1 |= (1 << 10);                     /* ACK, only after PE   */

    while (1) {
        if (!(I2C1->SR1 & (1 << 1))) continue;  /* ADDR = we are called */
        (void)I2C1->SR1;
        (void)I2C1->SR2;                        /* clears ADDR          */

        WAIT(I2C1->SR1 & (1 << 6));             /* RXNE                 */
        c = (uint8_t)I2C1->DR;

        blink(c == 'L' ? 1000 : 150);

        (void)I2C1->SR1;
        I2C1->CR1 |= 1;                         /* clears STOPF         */
    }
}
