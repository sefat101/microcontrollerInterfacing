/*=============================================================================
 *  EXPERIMENT 4 : I2C (I2C1, STANDARD MODE 100 kHz)         ---  S L A V E  ---
 *  Board  : NUCLEO-F446RE   (STM32F446RET6, Cortex-M4)
 *  Style  : 100 % bare-metal CMSIS register programming - no HAL, no CubeMX.
 *
 *  SLAVE SPECIFICS
 *      OAR1 holds the 7-bit own address in bits [7:1].  Bit 14 of OAR1 must
 *      always be written to 1 (reserved, see RM0390) or address matching is
 *      unreliable.  ACK (CR1.ACK) must be set AFTER PE = 1, otherwise it is
 *      cleared again by the peripheral enable sequence.
 *      A slave never programs CCR - the master supplies SCL.
 *
 *      Address matched          -> SR1.ADDR = 1
 *      Direction of the frame   -> SR2.TRA  (0 = we receive, 1 = we transmit)
 *      ADDR is cleared by reading SR1 and then SR2 (the classic STM32 dance)
 *      STOPF is cleared by reading SR1 and then WRITING to CR1
 *
 *  WIRING
 *      PB8 SCL (CN10-3 / D15) <-> master PB8   + 4k7 pull-up to 3V3
 *      PB9 SDA (CN10-5 / D14) <-> master PB9   + 4k7 pull-up to 3V3
 *      GND     (CN10-20)      <-> master GND
 *
 *  BLINK SPECIFICATION
 *      CMD_SHORT (0xA1) -> 3 blinks, 150 ms ON / 150 ms OFF (300 ms spacing)
 *      CMD_LONG  (0xA2) -> 3 blinks, 1000 ms ON / 1000 ms OFF (2 s spacing)
 *===========================================================================*/

#include "stm32f446xx.h"
#include <stdint.h>

#define LED_PIN          5u        /* PA5 - LD2 green user LED               */
#define OWN_ADDR7        0x28u     /* must match SLAVE_ADDR7 in the master   */

#define CMD_SYNC         0xAAu
#define CMD_SHORT        0xA1u
#define CMD_LONG         0xA2u
#define ACK_BYTE         0x5Au

#define SHORT_ON_MS      150u
#define SHORT_OFF_MS     150u
#define SHORT_REPEAT     3u
#define LONG_ON_MS       1000u
#define LONG_OFF_MS      1000u
#define LONG_REPEAT      3u

#define EVT_TIMEOUT_MS   50u

/*======================= 1. CLOCK : HSI 16 MHz, no PLL =====================*/
static void clock_init_hsi_16mhz(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) { }

    FLASH->ACR = FLASH_ACR_LATENCY_0WS;

    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

/*========================= 2. SysTick 1 ms time base =======================*/
static volatile uint32_t s_ticks;

void SysTick_Handler(void) { s_ticks++; }

static void systick_init(void)
{
    SysTick->LOAD = 16000u - 1u;
    SysTick->VAL  = 0u;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
}
static uint32_t millis(void) { return s_ticks; }
static void delay_ms(uint32_t ms)
{
    uint32_t t0 = s_ticks;
    while ((uint32_t)(s_ticks - t0) < ms) { __NOP(); }
}

/*============================ 3. On-board LD2 ==============================*/
static void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;

    GPIOA->MODER   &= ~(3u << (LED_PIN * 2u));
    GPIOA->MODER   |=  (1u << (LED_PIN * 2u));
    GPIOA->OTYPER  &= ~(1u << LED_PIN);
    GPIOA->OSPEEDR &= ~(3u << (LED_PIN * 2u));
    GPIOA->PUPDR   &= ~(3u << (LED_PIN * 2u));
    GPIOA->BSRR     =  (1u << (LED_PIN + 16u));
}
static void led_on (void) { GPIOA->BSRR = (1u << LED_PIN); }
static void led_off(void) { GPIOA->BSRR = (1u << (LED_PIN + 16u)); }

static void run_pattern(uint8_t cmd)
{
    uint32_t i, n, on, off;

    if (cmd == CMD_LONG) { n = LONG_REPEAT;  on = LONG_ON_MS;  off = LONG_OFF_MS;  }
    else                 { n = SHORT_REPEAT; on = SHORT_ON_MS; off = SHORT_OFF_MS; }

    for (i = 0u; i < n; i++) {
        led_on();  delay_ms(on);
        led_off(); delay_ms(off);
    }
}

/*========================== 4. I2C1 in SLAVE mode ==========================*/
static void i2c1_slave_init(uint8_t addr7)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;
    (void)RCC->APB1ENR;

    GPIOB->MODER   &= ~((3u << (8u*2u)) | (3u << (9u*2u)));
    GPIOB->MODER   |=  ((2u << (8u*2u)) | (2u << (9u*2u)));
    GPIOB->OTYPER  |=  ((1u << 8u) | (1u << 9u));             /* OPEN DRAIN  */
    GPIOB->OSPEEDR |=  ((3u << (8u*2u)) | (3u << (9u*2u)));
    GPIOB->PUPDR   &= ~((3u << (8u*2u)) | (3u << (9u*2u)));
    GPIOB->PUPDR   |=  ((1u << (8u*2u)) | (1u << (9u*2u)));

    GPIOB->AFR[1] &= ~((0xFu << ((8u-8u)*4u)) | (0xFu << ((9u-8u)*4u)));
    GPIOB->AFR[1] |=  ((4u   << ((8u-8u)*4u)) | (4u   << ((9u-8u)*4u)));

    RCC->APB1RSTR |=  RCC_APB1RSTR_I2C1RST;
    RCC->APB1RSTR &= ~RCC_APB1RSTR_I2C1RST;

    I2C1->CR1   = 0u;
    I2C1->CR2   = 16u;                          /* FREQ = 16 MHz             */
    I2C1->OAR1  = ((uint32_t)addr7 << 1u) | (1u << 14u);  /* bit14 must be 1 */
    I2C1->OAR2  = 0u;
    I2C1->CCR   = 80u;                          /* harmless in slave mode    */
    I2C1->TRISE = 17u;
    I2C1->CR1  |= I2C_CR1_PE;
    I2C1->CR1  |= I2C_CR1_ACK;                  /* ACK only *after* PE = 1   */
}

/*================================= main ====================================*/
int main(void)
{
    uint8_t  buf[4], cmd = 0u, valid = 0u;
    uint32_t sr2, n, t0;

    clock_init_hsi_16mhz();
    systick_init();
    led_init();
    i2c1_slave_init(OWN_ADDR7);

    led_on(); delay_ms(300u); led_off();          /* "slave alive" signal    */

    for (;;) {
        if ((I2C1->SR1 & I2C_SR1_ADDR) == 0u) { continue; }

        (void)I2C1->SR1;
        sr2 = I2C1->SR2;                          /* reading SR2 clears ADDR */

        if (sr2 & I2C_SR2_TRA) {
            /*---------------- master is READING from us -------------------*/
            t0 = millis();
            while ((I2C1->SR1 & I2C_SR1_TXE) == 0u) {
                if ((uint32_t)(millis() - t0) > EVT_TIMEOUT_MS) { break; }
            }
            I2C1->DR = valid ? (uint32_t)ACK_BYTE : 0x00u;

            /* the master NACKs the single byte -> AF is set; clear it       */
            t0 = millis();
            while ((I2C1->SR1 & I2C_SR1_AF) == 0u) {
                if ((uint32_t)(millis() - t0) > EVT_TIMEOUT_MS) { break; }
            }
            I2C1->SR1 &= ~I2C_SR1_AF;
            I2C1->CR1 |= I2C_CR1_ACK;             /* re-arm for next frame   */

            if (valid) {
                valid = 0u;
                run_pattern(cmd);                 /* bus is free again now   */
            }
        } else {
            /*---------------- master is WRITING to us ---------------------*/
            n  = 0u;
            t0 = millis();
            for (;;) {
                uint32_t sr1 = I2C1->SR1;

                if (sr1 & I2C_SR1_RXNE) {
                    uint8_t b = (uint8_t)I2C1->DR;
                    if (n < 4u) { buf[n] = b; }
                    n++;
                    t0 = millis();
                } else if (sr1 & I2C_SR1_STOPF) {
                    (void)I2C1->SR1;
                    I2C1->CR1 |= I2C_CR1_PE;      /* write to CR1 clears STOPF */
                    break;
                } else if ((uint32_t)(millis() - t0) > EVT_TIMEOUT_MS) {
                    break;
                }
            }

            if (n >= 3u && buf[0] == CMD_SYNC &&
                (uint8_t)(buf[1] ^ 0xFFu) == buf[2] &&
                (buf[1] == CMD_SHORT || buf[1] == CMD_LONG)) {
                cmd   = buf[1];
                valid = 1u;                       /* answer on the next read */
            }
            I2C1->CR1 |= I2C_CR1_ACK;
        }
    }
}
