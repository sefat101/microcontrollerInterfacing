/*=============================================================================
 *  EXPERIMENT 4 : I2C (I2C1, STANDARD MODE 100 kHz)        ---  M A S T E R  ---
 *  Board  : NUCLEO-F446RE   (STM32F446RET6, Cortex-M4)
 *  Style  : 100 % bare-metal CMSIS register programming - no HAL, no CubeMX.
 *
 *  BUS SETTINGS
 *      PB8 = I2C1_SCL (AF4, Arduino D15)   PB9 = I2C1_SDA (AF4, Arduino D14)
 *      Both pins are ALTERNATE FUNCTION + OPEN DRAIN - this is what makes the
 *      wired-AND bus possible.  Pull-up resistors are mandatory:
 *          4.7 kOhm from SCL to +3V3  and  4.7 kOhm from SDA to +3V3
 *      (the internal ~40 kOhm pull-ups are enabled as a fallback only).
 *
 *      FREQ  = 16        APB1 clock in MHz, tells the peripheral its input clk
 *      CCR   = 80        Sm mode: CCR = fPCLK1 / (2 x fSCL) = 16e6/(2x100e3)
 *      TRISE = 17        max rise time 1000 ns / 62.5 ns + 1
 *
 *  TRANSACTION (7-bit slave address 0x28)
 *      1) WRITE  [0xAA sync][cmd][~cmd]      -> slave stores the command
 *      2) READ   1 byte                      -> slave answers ACK = 0x5A
 *      3) slave then plays the LED pattern; the bus is already free
 *
 *  WIRING (bus - both signals are common, NOT crossed)
 *      PB8 SCL (CN10-3 / D15) <-> PB8 SCL (CN10-3 / D15)  + 4k7 to 3V3
 *      PB9 SDA (CN10-5 / D14) <-> PB9 SDA (CN10-5 / D14)  + 4k7 to 3V3
 *      GND     (CN10-20)      <-> GND     (CN10-20)
 *      3V3 for the pull-ups may come from either board (CN7-16).
 *
 *  Optional RGB status LED on the MASTER (common cathode + 3 x 330 R):
 *      PC0 = RED (CN7-38), PC1 = GREEN (CN7-36), PC2 = BLUE (CN7-35).
 *===========================================================================*/

#include "stm32f446xx.h"
#include <stdint.h>

/*--------------------------- user configuration ---------------------------*/
#define USE_RGB            1u
#define RGB_COMMON_CATHODE 1u

#define LED_PIN          5u        /* PA5  - LD2 green user LED              */
#define BTN_PIN          13u       /* PC13 - B1  blue user button            */

#define SLAVE_ADDR7      0x28u     /* 7-bit address of the slave board       */

#define CMD_SYNC         0xAAu
#define CMD_SHORT        0xA1u
#define CMD_LONG         0xA2u
#define ACK_BYTE         0x5Au

#define T_DEBOUNCE_MS    20u
#define T_LONG_MS        1000u
#define I2C_TIMEOUT_MS   25u

/*======================= 1. CLOCK : HSI 16 MHz, no PLL =====================*/
static void clock_init_hsi_16mhz(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) { }

    FLASH->ACR = FLASH_ACR_LATENCY_0WS;

    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

/*========================= 2. SysTick 1 ms time base =======================*/
static volatile uint32_t s_ticks;

void SysTick_Handler(void) { s_ticks++; }

static void systick_init(void)
{
    SysTick->LOAD = 16000u - 1u;
    SysTick->VAL  = 0u;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
}
static uint32_t millis(void) { return s_ticks; }
static void delay_ms(uint32_t ms)
{
    uint32_t t0 = s_ticks;
    while ((uint32_t)(s_ticks - t0) < ms) { __NOP(); }
}

/*============================ 3. LD2 and B1 ================================*/
static void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;

    GPIOA->MODER   &= ~(3u << (LED_PIN * 2u));
    GPIOA->MODER   |=  (1u << (LED_PIN * 2u));
    GPIOA->OTYPER  &= ~(1u << LED_PIN);
    GPIOA->OSPEEDR &= ~(3u << (LED_PIN * 2u));
    GPIOA->PUPDR   &= ~(3u << (LED_PIN * 2u));
    GPIOA->BSRR     =  (1u << (LED_PIN + 16u));
}
static void led_on (void) { GPIOA->BSRR = (1u << LED_PIN); }
static void led_off(void) { GPIOA->BSRR = (1u << (LED_PIN + 16u)); }

static void button_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;

    GPIOC->MODER &= ~(3u << (BTN_PIN * 2u));
    GPIOC->PUPDR &= ~(3u << (BTN_PIN * 2u));
    GPIOC->PUPDR |=  (1u << (BTN_PIN * 2u));
}
static uint32_t button_down(void)
{
    return ((GPIOC->IDR & (1u << BTN_PIN)) == 0u);
}
static uint8_t button_capture(uint32_t *press_ms)
{
    uint32_t t0, d;

    if (!button_down())  return 0u;
    delay_ms(T_DEBOUNCE_MS);
    if (!button_down())  return 0u;

    t0 = millis();
    while (button_down()) { __NOP(); }
    delay_ms(T_DEBOUNCE_MS);

    d = millis() - t0;
    if (press_ms != 0) { *press_ms = d; }
    return (d >= T_LONG_MS) ? CMD_LONG : CMD_SHORT;
}

/*======================== 4. Optional RGB indicator ========================*/
static void rgb_init(void)
{
#if USE_RGB
    uint32_t p;
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;
    for (p = 0u; p <= 2u; p++) {
        GPIOC->MODER  &= ~(3u << (p * 2u));
        GPIOC->MODER  |=  (1u << (p * 2u));
        GPIOC->OTYPER &= ~(1u << p);
        GPIOC->PUPDR  &= ~(3u << (p * 2u));
    }
#endif
}
static void rgb_set(uint32_t r, uint32_t g, uint32_t b)
{
#if USE_RGB
  #if RGB_COMMON_CATHODE
    GPIOC->BSRR = (r ? (1u << 0) : (1u << 16)) |
                  (g ? (1u << 1) : (1u << 17)) |
                  (b ? (1u << 2) : (1u << 18));
  #else
    GPIOC->BSRR = (r ? (1u << 16) : (1u << 0)) |
                  (g ? (1u << 17) : (1u << 1)) |
                  (b ? (1u << 18) : (1u << 2));
  #endif
#else
    (void)r; (void)g; (void)b;
#endif
}
static void master_indicate(uint32_t ok)
{
    uint32_t i;
    if (ok) {
        rgb_set(0u, 1u, 0u);
        led_on(); delay_ms(250u); led_off();
    } else {
        rgb_set(1u, 0u, 0u);
        for (i = 0u; i < 3u; i++) { led_on(); delay_ms(60u); led_off(); delay_ms(60u); }
    }
    rgb_set(0u, 0u, 0u);
}

/*========================= 5. I2C1 in MASTER mode ==========================*/
static void i2c1_master_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_I2C1EN;
    (void)RCC->APB1ENR;

    GPIOB->MODER   &= ~((3u << (8u*2u)) | (3u << (9u*2u)));
    GPIOB->MODER   |=  ((2u << (8u*2u)) | (2u << (9u*2u)));   /* 10 = AF     */
    GPIOB->OTYPER  |=  ((1u << 8u) | (1u << 9u));             /* OPEN DRAIN  */
    GPIOB->OSPEEDR |=  ((3u << (8u*2u)) | (3u << (9u*2u)));
    GPIOB->PUPDR   &= ~((3u << (8u*2u)) | (3u << (9u*2u)));
    GPIOB->PUPDR   |=  ((1u << (8u*2u)) | (1u << (9u*2u)));   /* weak pull-up */

    GPIOB->AFR[1] &= ~((0xFu << ((8u-8u)*4u)) | (0xFu << ((9u-8u)*4u)));
    GPIOB->AFR[1] |=  ((4u   << ((8u-8u)*4u)) | (4u   << ((9u-8u)*4u))); /* AF4 */

    /* Reset the peripheral so a half-finished transfer cannot lock the bus. */
    RCC->APB1RSTR |=  RCC_APB1RSTR_I2C1RST;
    RCC->APB1RSTR &= ~RCC_APB1RSTR_I2C1RST;

    I2C1->CR1   = 0u;
    I2C1->CR2   = 16u;                 /* FREQ[5:0] = APB1 clock in MHz      */
    I2C1->CCR   = 80u;                 /* Sm, 100 kHz                        */
    I2C1->TRISE = 17u;                 /* 1000 ns max rise time              */
    I2C1->CR1  |= I2C_CR1_PE;
}

static uint32_t i2c_wait(uint32_t mask, uint32_t ms)
{
    uint32_t t0 = millis();
    while ((I2C1->SR1 & mask) == 0u) {
        if (I2C1->SR1 & I2C_SR1_AF) { I2C1->SR1 &= ~I2C_SR1_AF; return 0u; }
        if ((uint32_t)(millis() - t0) > ms) { return 0u; }
    }
    return 1u;
}
static void i2c_abort(void)
{
    I2C1->CR1 |= I2C_CR1_STOP;
    I2C1->SR1  = 0u;                   /* clear AF / BERR / ARLO             */
}

/* Master transmitter: START - address+W - n data bytes - STOP. */
static uint32_t i2c1_write(uint8_t addr7, const uint8_t *data, uint32_t n)
{
    uint32_t i, t0 = millis();

    while (I2C1->SR2 & I2C_SR2_BUSY) {
        if ((uint32_t)(millis() - t0) > I2C_TIMEOUT_MS) { return 0u; }
    }

    I2C1->CR1 |= I2C_CR1_START;
    if (!i2c_wait(I2C_SR1_SB, I2C_TIMEOUT_MS))    { i2c_abort(); return 0u; }
    (void)I2C1->SR1;
    I2C1->DR = (uint32_t)(addr7 << 1u);                       /* R/W = 0     */

    if (!i2c_wait(I2C_SR1_ADDR, I2C_TIMEOUT_MS))  { i2c_abort(); return 0u; }
    (void)I2C1->SR1; (void)I2C1->SR2;                          /* clear ADDR  */

    for (i = 0u; i < n; i++) {
        if (!i2c_wait(I2C_SR1_TXE, I2C_TIMEOUT_MS)) { i2c_abort(); return 0u; }
        I2C1->DR = (uint32_t)data[i];
    }
    if (!i2c_wait(I2C_SR1_BTF, I2C_TIMEOUT_MS))   { i2c_abort(); return 0u; }

    I2C1->CR1 |= I2C_CR1_STOP;
    return 1u;
}

/* Master receiver, single byte (RM0390 "one byte" procedure). */
static uint32_t i2c1_read1(uint8_t addr7, uint8_t *b)
{
    uint32_t t0 = millis();

    while (I2C1->SR2 & I2C_SR2_BUSY) {
        if ((uint32_t)(millis() - t0) > I2C_TIMEOUT_MS) { return 0u; }
    }

    I2C1->CR1 &= ~I2C_CR1_ACK;                    /* NACK the only byte      */
    I2C1->CR1 |=  I2C_CR1_START;
    if (!i2c_wait(I2C_SR1_SB, I2C_TIMEOUT_MS))    { i2c_abort(); return 0u; }
    (void)I2C1->SR1;
    I2C1->DR = (uint32_t)((addr7 << 1u) | 1u);                 /* R/W = 1     */

    if (!i2c_wait(I2C_SR1_ADDR, I2C_TIMEOUT_MS))  { i2c_abort(); return 0u; }
    (void)I2C1->SR1; (void)I2C1->SR2;                          /* clear ADDR  */
    I2C1->CR1 |= I2C_CR1_STOP;                    /* STOP right after ADDR   */

    if (!i2c_wait(I2C_SR1_RXNE, I2C_TIMEOUT_MS))  { i2c_abort(); return 0u; }
    *b = (uint8_t)I2C1->DR;
    return 1u;
}

/*================================= main ====================================*/
int main(void)
{
    uint8_t  cmd, ack, frame[3];
    uint32_t press_ms, ok;

    clock_init_hsi_16mhz();
    systick_init();
    led_init();
    button_init();
    rgb_init();
    i2c1_master_init();

    rgb_set(0u, 0u, 1u); led_on(); delay_ms(300u); led_off(); rgb_set(0u,0u,0u);

    for (;;) {
        press_ms = 0u;
        cmd = button_capture(&press_ms);
        if (cmd == 0u) { continue; }

        frame[0] = CMD_SYNC;
        frame[1] = cmd;
        frame[2] = (uint8_t)(cmd ^ 0xFFu);

        rgb_set(0u, 0u, 1u);

        ok  = i2c1_write(SLAVE_ADDR7, frame, 3u);
        ack = 0u;
        if (ok) {
            delay_ms(2u);                          /* let the slave re-arm   */
            ok = i2c1_read1(SLAVE_ADDR7, &ack) && (ack == ACK_BYTE);
        }

        rgb_set(0u, 0u, 0u);
        master_indicate(ok);
    }
}
