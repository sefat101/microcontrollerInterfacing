/* EXP 4  I2C1 (100 kHz, slave address 0x28)  --- MASTER --- NUCLEO-F446RE
 * Wiring : PB8 SCL (CN10-3 / D15) <-> slave PB8   + 4.7k to +3V3
 *          PB9 SDA (CN10-5 / D14) <-> slave PB9   + 4.7k to +3V3
 *          GND     (CN10-20)      <-> slave GND
 * The pull-ups are NOT optional: both pins are open drain.            */

#include "stm32f446xx.h"

#define WAIT(c) { uint32_t w = 200000; while (!(c) && --w); }

static void delay_ms(uint32_t ms)
{
    SysTick->LOAD = 16000 - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;
    while (ms--) while (!(SysTick->CTRL & (1 << 16)));
    SysTick->CTRL = 0;
}

static void i2c_send(uint8_t b)
{
    I2C1->CR1 |= (1 << 8);                      /* START                */
    WAIT(I2C1->SR1 & (1 << 0));                 /* SB                   */
    I2C1->DR = 0x28 << 1;                       /* address + write bit  */
    WAIT(I2C1->SR1 & (1 << 1));                 /* ADDR                 */
    (void)I2C1->SR2;                            /* SR1+SR2 clears ADDR  */
    WAIT(I2C1->SR1 & (1 << 7));                 /* TXE                  */
    I2C1->DR = b;
    WAIT(I2C1->SR1 & (1 << 2));                 /* BTF                  */
    I2C1->CR1 |= (1 << 9);                      /* STOP                 */
}

int main(void)
{
    uint32_t t;

    RCC->AHB1ENR |= (1 << 0) | (1 << 1) | (1 << 2);   /* GPIOA, B, C    */
    RCC->APB1ENR |= (1 << 21);                        /* I2C1           */

    GPIOC->PUPDR  |= (1 << 26);                 /* PC13 pull-up  (B1)   */
    GPIOA->MODER  |= (1 << 10);                 /* PA5 output    (LD2)  */
    GPIOB->MODER  |= (2 << 16) | (2 << 18);     /* PB8, PB9 alternate   */
    GPIOB->OTYPER |= (1 << 8) | (1 << 9);       /* OPEN DRAIN           */
    GPIOB->AFR[1] |= (4 << 0) | (4 << 4);       /* AF4 = I2C1           */

    I2C1->CR2   = 16;                           /* PCLK1 = 16 MHz       */
    I2C1->CCR   = 80;                           /* 16e6 / (2 x 100e3)   */
    I2C1->TRISE = 17;                           /* 1000 ns / 62.5 ns +1 */
    I2C1->CR1   = 1;                            /* PE                   */

    while (1) {
        if (GPIOC->IDR & (1 << 13)) continue;

        t = 0;
        while (!(GPIOC->IDR & (1 << 13))) { delay_ms(10); t += 10; }

        i2c_send((t >= 1000) ? 'L' : 'S');

        GPIOA->ODR |=  (1 << 5);
        delay_ms(100);
        GPIOA->ODR &= ~(1 << 5);
    }
}
