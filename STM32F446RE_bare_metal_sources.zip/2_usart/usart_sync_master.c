/* EXP 2  USART SYNCHRONOUS (USART1 + CK)  --- MASTER ---  NUCLEO-F446RE
 * Wiring : PA9 TX (CN10-21) -> slave PB15 (CN10-26)   data
 *          PA8 CK (CN10-23) -> slave PB13 (CN10-30)   clock
 *          GND    (CN10-20) -> slave GND  (CN10-20)
 * CR2: CLKEN=1 CPOL=0 CPHA=1 LBCL=1  (write CR2 before TE)            */

#include "stm32f446xx.h"

static void delay_ms(uint32_t ms)
{
    SysTick->LOAD = 16000 - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;
    while (ms--) while (!(SysTick->CTRL & (1 << 16)));
    SysTick->CTRL = 0;
}

int main(void)
{
    uint32_t t;

    RCC->AHB1ENR |= (1 << 0) | (1 << 2);        /* GPIOA, GPIOC         */
    RCC->APB2ENR |= (1 << 4);                   /* USART1               */

    GPIOC->PUPDR  |= (1 << 26);                 /* PC13 pull-up  (B1)   */
    GPIOA->MODER  |= (1 << 10);                 /* PA5  output   (LD2)  */
    GPIOA->MODER  |= (2 << 16) | (2 << 18);     /* PA8, PA9 alternate   */
    GPIOA->AFR[1] |= (7 << 0) | (7 << 4);       /* AF7 = CK and TX      */

    USART1->CR2 = (1 << 11) | (1 << 9) | (1 << 8);   /* CLKEN,CPHA,LBCL */
    USART1->BRR = 1667;                              /* CK = 9.6 kHz    */
    USART1->CR1 = (1 << 3) | (1 << 13);              /* TE, UE          */

    while (1) {
        if (GPIOC->IDR & (1 << 13)) continue;

        t = 0;
        while (!(GPIOC->IDR & (1 << 13))) { delay_ms(10); t += 10; }

        while (!(USART1->SR & (1 << 7)));       /* TXE                  */
        USART1->DR = (t >= 1000) ? 'L' : 'S';

        GPIOA->ODR |=  (1 << 5);
        delay_ms(100);
        GPIOA->ODR &= ~(1 << 5);
    }
}
