/*=============================================================================
 *  EXPERIMENT 2 : USART - SYNCHRONOUS MODE                 ---  M A S T E R  ---
 *  Board  : NUCLEO-F446RE   (STM32F446RET6, Cortex-M4)
 *  Style  : 100 % bare-metal CMSIS register programming - no HAL, no CubeMX.
 *
 *  WHAT IS DIFFERENT FROM EXPERIMENT 1
 *      Here USART1 runs in SYNCHRONOUS mode: CR2.CLKEN = 1 makes the peripheral
 *      output a bit clock on USART1_CK (PA8) that is strictly aligned with the
 *      data bits on USART1_TX (PA9).  There is no baud-rate agreement problem
 *      any more - the receiver is clocked by the transmitter.
 *      CPOL = 0 (clock idles low), CPHA = 1 (data captured on the 2nd edge),
 *      LBCL = 1 (a clock pulse is also produced for the last = 8th data bit).
 *
 *  IMPORTANT HARDWARE FACT (state this in your lab report)
 *      On STM32 the USART can only be the SYNCHRONOUS **MASTER** - USART_CK is
 *      an output-only pin, the receiver cannot be driven by an external clock.
 *      Therefore the slave board captures the clocked data with its SPI
 *      peripheral in slave mode (see the slave source file), and the return
 *      acknowledgement travels on a dedicated 1-wire handshake line PC8.
 *
 *  WIRING (master -> slave)
 *      PA9  USART1_TX (CN10-21 / D8) -> PB15 SPI2_MOSI (CN10-26)   data
 *      PA8  USART1_CK (CN10-23 / D7) -> PB13 SPI2_SCK  (CN10-30)   clock
 *      PC8  ACK-IN    (CN10-2)       <- PC8  ACK-OUT   (CN10-2)    handshake
 *      GND            (CN10-20)      <-> GND           (CN10-20)   common 0 V
 *
 *  Optional RGB status LED on the MASTER (common cathode + 3 x 330 R):
 *      PC0 = RED (CN7-38), PC1 = GREEN (CN7-36), PC2 = BLUE (CN7-35).
 *===========================================================================*/

#include "stm32f446xx.h"
#include <stdint.h>

/*--------------------------- user configuration ---------------------------*/
#define USE_RGB            1u
#define RGB_COMMON_CATHODE 1u

#define LED_PIN          5u        /* PA5  - LD2 green user LED              */
#define BTN_PIN          13u       /* PC13 - B1  blue user button            */
#define ACK_PIN          8u        /* PC8  - handshake input from the slave  */

#define CMD_SYNC         0xAAu
#define CMD_SHORT        0xA1u
#define CMD_LONG         0xA2u

#define T_DEBOUNCE_MS    20u
#define T_LONG_MS        1000u
#define T_ACK_MS         500u

/*======================= 1. CLOCK : HSI 16 MHz, no PLL =====================*/
static void clock_init_hsi_16mhz(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) { }

    FLASH->ACR = FLASH_ACR_LATENCY_0WS;

    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

/*========================= 2. SysTick 1 ms time base =======================*/
static volatile uint32_t s_ticks;

void SysTick_Handler(void) { s_ticks++; }

static void systick_init(void)
{
    SysTick->LOAD = 16000u - 1u;
    SysTick->VAL  = 0u;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
}
static uint32_t millis(void) { return s_ticks; }
static void delay_ms(uint32_t ms)
{
    uint32_t t0 = s_ticks;
    while ((uint32_t)(s_ticks - t0) < ms) { __NOP(); }
}

/*==================== 3. LD2, B1 and the ACK handshake pin =================*/
static void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;

    GPIOA->MODER   &= ~(3u << (LED_PIN * 2u));
    GPIOA->MODER   |=  (1u << (LED_PIN * 2u));
    GPIOA->OTYPER  &= ~(1u << LED_PIN);
    GPIOA->OSPEEDR &= ~(3u << (LED_PIN * 2u));
    GPIOA->PUPDR   &= ~(3u << (LED_PIN * 2u));
    GPIOA->BSRR     =  (1u << (LED_PIN + 16u));
}
static void led_on (void) { GPIOA->BSRR = (1u << LED_PIN); }
static void led_off(void) { GPIOA->BSRR = (1u << (LED_PIN + 16u)); }

static void button_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;

    GPIOC->MODER &= ~(3u << (BTN_PIN * 2u));
    GPIOC->PUPDR &= ~(3u << (BTN_PIN * 2u));
    GPIOC->PUPDR |=  (1u << (BTN_PIN * 2u));
}
static uint32_t button_down(void)
{
    return ((GPIOC->IDR & (1u << BTN_PIN)) == 0u);
}
static uint8_t button_capture(uint32_t *press_ms)
{
    uint32_t t0, d;

    if (!button_down())  return 0u;
    delay_ms(T_DEBOUNCE_MS);
    if (!button_down())  return 0u;

    t0 = millis();
    while (button_down()) { __NOP(); }
    delay_ms(T_DEBOUNCE_MS);

    d = millis() - t0;
    if (press_ms != 0) { *press_ms = d; }
    return (d >= T_LONG_MS) ? CMD_LONG : CMD_SHORT;
}

/* PC8 = digital input with pull-DOWN; the slave drives it HIGH for ~10 ms. */
static void ackpin_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;

    GPIOC->MODER &= ~(3u << (ACK_PIN * 2u));     /* 00 = input               */
    GPIOC->PUPDR &= ~(3u << (ACK_PIN * 2u));
    GPIOC->PUPDR |=  (2u << (ACK_PIN * 2u));     /* 10 = pull-down           */
}
static uint32_t ack_wait(uint32_t timeout_ms)
{
    uint32_t t0 = millis();
    while ((uint32_t)(millis() - t0) < timeout_ms) {
        if (GPIOC->IDR & (1u << ACK_PIN)) {
            while (GPIOC->IDR & (1u << ACK_PIN)) { __NOP(); }  /* eat pulse  */
            return 1u;
        }
    }
    return 0u;
}

/*======================== 4. Optional RGB indicator ========================*/
static void rgb_init(void)
{
#if USE_RGB
    uint32_t p;
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;
    for (p = 0u; p <= 2u; p++) {
        GPIOC->MODER  &= ~(3u << (p * 2u));
        GPIOC->MODER  |=  (1u << (p * 2u));
        GPIOC->OTYPER &= ~(1u << p);
        GPIOC->PUPDR  &= ~(3u << (p * 2u));
    }
#endif
}
static void rgb_set(uint32_t r, uint32_t g, uint32_t b)
{
#if USE_RGB
  #if RGB_COMMON_CATHODE
    GPIOC->BSRR = (r ? (1u << 0) : (1u << 16)) |
                  (g ? (1u << 1) : (1u << 17)) |
                  (b ? (1u << 2) : (1u << 18));
  #else
    GPIOC->BSRR = (r ? (1u << 16) : (1u << 0)) |
                  (g ? (1u << 17) : (1u << 1)) |
                  (b ? (1u << 18) : (1u << 2));
  #endif
#else
    (void)r; (void)g; (void)b;
#endif
}
static void master_indicate(uint32_t ok)
{
    uint32_t i;
    if (ok) {
        rgb_set(0u, 1u, 0u);
        led_on(); delay_ms(250u); led_off();
    } else {
        rgb_set(1u, 0u, 0u);
        for (i = 0u; i < 3u; i++) { led_on(); delay_ms(60u); led_off(); delay_ms(60u); }
    }
    rgb_set(0u, 0u, 0u);
}

/*=================== 5. USART1 in SYNCHRONOUS MASTER mode ==================*/
/*  PA8 = USART1_CK (AF7)      PA9 = USART1_TX (AF7)
 *  BRR = 1667  ->  9600 bit/s, i.e. CK runs at 9.6 kHz.
 *  CR2.CLKEN / CPOL / CPHA / LBCL must be written while TE = 0 (RM0390).   */
static void usart1_sync_master_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
    (void)RCC->APB2ENR;

    GPIOA->MODER   &= ~((3u << (8u * 2u)) | (3u << (9u * 2u)));
    GPIOA->MODER   |=  ((2u << (8u * 2u)) | (2u << (9u * 2u)));    /* 10 = AF */
    GPIOA->OTYPER  &= ~((1u << 8u) | (1u << 9u));
    GPIOA->OSPEEDR |=  ((3u << (8u * 2u)) | (3u << (9u * 2u)));

    GPIOA->AFR[1] &= ~((0xFu << ((8u - 8u) * 4u)) | (0xFu << ((9u - 8u) * 4u)));
    GPIOA->AFR[1] |=  ((7u   << ((8u - 8u) * 4u)) | (7u   << ((9u - 8u) * 4u)));

    USART1->CR1 = 0u;                       /* TE = 0 while configuring CR2  */
    USART1->CR3 = 0u;
    USART1->CR2 = USART_CR2_CLKEN |         /* drive the CK pin              */
                  USART_CR2_LBCL  |         /* clock pulse for the last bit  */
                  USART_CR2_CPHA;           /* CPHA = 1, CPOL = 0            */
    USART1->BRR = 1667u;
    USART1->CR1 = USART_CR1_TE | USART_CR1_UE;   /* transmit only            */
}
static void usart1_write(uint8_t b)
{
    while ((USART1->SR & USART_SR_TXE) == 0u) { }
    USART1->DR = (uint32_t)b;
}
static void usart1_flush(void)
{
    while ((USART1->SR & USART_SR_TC) == 0u) { }
}

/*================================= main ====================================*/
int main(void)
{
    uint8_t  cmd;
    uint32_t press_ms, ok;

    clock_init_hsi_16mhz();
    systick_init();
    led_init();
    button_init();
    ackpin_init();
    rgb_init();
    usart1_sync_master_init();

    rgb_set(0u, 0u, 1u); led_on(); delay_ms(300u); led_off(); rgb_set(0u,0u,0u);

    for (;;) {
        press_ms = 0u;
        cmd = button_capture(&press_ms);
        if (cmd == 0u) { continue; }

        rgb_set(0u, 0u, 1u);

        usart1_write(CMD_SYNC);
        usart1_write(cmd);
        usart1_write((uint8_t)(cmd ^ 0xFFu));
        usart1_flush();

        rgb_set(0u, 0u, 0u);

        ok = ack_wait(T_ACK_MS);
        master_indicate(ok);
    }
}
