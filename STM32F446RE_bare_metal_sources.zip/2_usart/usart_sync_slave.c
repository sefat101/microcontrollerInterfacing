/* EXP 2  USART SYNCHRONOUS  ---  SLAVE  ---  NUCLEO-F446RE
 * USART_CK is OUTPUT ONLY on STM32, so a USART cannot be the synchronous
 * slave. SPI2 in slave mode is used instead: it is a shift register that
 * runs on the clock the master supplies.
 * Wiring : PB15 MOSI (CN10-26) <- master PA9 TX (CN10-21)
 *          PB13 SCK  (CN10-30) <- master PA8 CK (CN10-23)
 *          GND       (CN10-20) <- master GND    (CN10-20)
 * CR1: CPHA=1 CPOL=0 LSBFIRST=1 (a USART sends the LSB first) SSM=1    */

#include "stm32f446xx.h"

static void delay_ms(uint32_t ms)
{
    SysTick->LOAD = 16000 - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;
    while (ms--) while (!(SysTick->CTRL & (1 << 16)));
    SysTick->CTRL = 0;
}

static void blink(uint32_t d)
{
    for (int i = 0; i < 3; i++) {
        GPIOA->ODR |=  (1 << 5);  delay_ms(d);
        GPIOA->ODR &= ~(1 << 5);  delay_ms(d);
    }
}

int main(void)
{
    RCC->AHB1ENR |= (1 << 0) | (1 << 1);        /* GPIOA, GPIOB         */
    RCC->APB1ENR |= (1 << 14);                  /* SPI2                 */

    GPIOA->MODER  |= (1 << 10);                 /* PA5 output    (LD2)  */
    GPIOB->MODER  |= (2 << 26) | (2 << 30);     /* PB13, PB15 alternate */
    GPIOB->AFR[1] |= (5 << 20) | (5 << 28);     /* AF5 = SPI2           */

    SPI2->CR1 = (1 << 0) | (1 << 7) | (1 << 9) | (1 << 6);
    /*          CPHA       LSBFIRST   SSM(SSI=0)  SPE   -> slave, mode 1 */

    while (1)
        if (SPI2->SR & (1 << 0))                /* RXNE                 */
            blink((uint8_t)SPI2->DR == 'L' ? 1000 : 150);
}
