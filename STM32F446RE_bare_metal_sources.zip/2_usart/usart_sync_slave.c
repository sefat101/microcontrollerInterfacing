/*=============================================================================
 *  EXPERIMENT 2 : USART - SYNCHRONOUS MODE                  ---  S L A V E  ---
 *  Board  : NUCLEO-F446RE   (STM32F446RET6, Cortex-M4)
 *  Style  : 100 % bare-metal CMSIS register programming - no HAL, no CubeMX.
 *
 *  WHY SPI IS USED ON THIS SIDE
 *      An STM32 USART in synchronous mode can only be the clock MASTER; its
 *      USART_CK pin is an output.  To *receive* an externally clocked stream
 *      the slave board uses SPI2 in slave mode, which is a pure shift register
 *      driven by the incoming clock.  Configuration that makes SPI2 byte-
 *      compatible with a USART synchronous frame:
 *
 *          MSTR     = 0    slave, clock comes from outside
 *          CPOL     = 0    idle low   -> matches USART CPOL = 0
 *          CPHA     = 1    2nd edge   -> matches USART CPHA = 1
 *          LSBFIRST = 1    the USART shifts the LSB out first
 *          SSM = 1, SSI = 0  -> permanently "selected", no NSS wire needed
 *          DFF      = 0    8-bit frames
 *
 *      USART_CK produces exactly 8 pulses per character (LBCL = 1 adds the
 *      pulse for bit 7), so the SPI shift register delivers one clean byte per
 *      character.  The USART start/stop bits carry no clock and are ignored.
 *
 *  WIRING
 *      PB15 SPI2_MOSI (CN10-26) <- PA9 USART1_TX (master, CN10-21 / D8)
 *      PB13 SPI2_SCK  (CN10-30) <- PA8 USART1_CK (master, CN10-23 / D7)
 *      PC8  ACK-OUT   (CN10-2)  -> PC8 ACK-IN    (master, CN10-2)
 *      GND            (CN10-20) <-> GND          (master, CN10-20)
 *
 *  BLINK SPECIFICATION
 *      CMD_SHORT (0xA1) -> 3 blinks, 150 ms ON / 150 ms OFF (300 ms spacing)
 *      CMD_LONG  (0xA2) -> 3 blinks, 1000 ms ON / 1000 ms OFF (2 s spacing)
 *===========================================================================*/

#include "stm32f446xx.h"
#include <stdint.h>

#define LED_PIN          5u        /* PA5 - LD2 green user LED               */
#define ACK_PIN          8u        /* PC8 - handshake output to the master   */

#define CMD_SYNC         0xAAu
#define CMD_SHORT        0xA1u
#define CMD_LONG         0xA2u

#define SHORT_ON_MS      150u
#define SHORT_OFF_MS     150u
#define SHORT_REPEAT     3u
#define LONG_ON_MS       1000u
#define LONG_OFF_MS      1000u
#define LONG_REPEAT      3u

/*======================= 1. CLOCK : HSI 16 MHz, no PLL =====================*/
static void clock_init_hsi_16mhz(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) { }

    FLASH->ACR = FLASH_ACR_LATENCY_0WS;

    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

/*========================= 2. SysTick 1 ms time base =======================*/
static volatile uint32_t s_ticks;

void SysTick_Handler(void) { s_ticks++; }

static void systick_init(void)
{
    SysTick->LOAD = 16000u - 1u;
    SysTick->VAL  = 0u;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
}
static void delay_ms(uint32_t ms)
{
    uint32_t t0 = s_ticks;
    while ((uint32_t)(s_ticks - t0) < ms) { __NOP(); }
}

/*========================= 3. LD2 and the ACK pin ==========================*/
static void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;

    GPIOA->MODER   &= ~(3u << (LED_PIN * 2u));
    GPIOA->MODER   |=  (1u << (LED_PIN * 2u));
    GPIOA->OTYPER  &= ~(1u << LED_PIN);
    GPIOA->OSPEEDR &= ~(3u << (LED_PIN * 2u));
    GPIOA->PUPDR   &= ~(3u << (LED_PIN * 2u));
    GPIOA->BSRR     =  (1u << (LED_PIN + 16u));
}
static void led_on (void) { GPIOA->BSRR = (1u << LED_PIN); }
static void led_off(void) { GPIOA->BSRR = (1u << (LED_PIN + 16u)); }

static void ackpin_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;

    GPIOC->MODER   &= ~(3u << (ACK_PIN * 2u));
    GPIOC->MODER   |=  (1u << (ACK_PIN * 2u));   /* push-pull output         */
    GPIOC->OTYPER  &= ~(1u << ACK_PIN);
    GPIOC->PUPDR   &= ~(3u << (ACK_PIN * 2u));
    GPIOC->BSRR     =  (1u << (ACK_PIN + 16u));  /* idle LOW                 */
}
static void ack_pulse(void)
{
    GPIOC->BSRR = (1u << ACK_PIN);
    delay_ms(10u);
    GPIOC->BSRR = (1u << (ACK_PIN + 16u));
}

static void run_pattern(uint8_t cmd)
{
    uint32_t i, n, on, off;

    if (cmd == CMD_LONG) { n = LONG_REPEAT;  on = LONG_ON_MS;  off = LONG_OFF_MS;  }
    else                 { n = SHORT_REPEAT; on = SHORT_ON_MS; off = SHORT_OFF_MS; }

    for (i = 0u; i < n; i++) {
        led_on();  delay_ms(on);
        led_off(); delay_ms(off);
    }
}

/*============ 4. SPI2 as an externally clocked byte receiver ===============*/
/*  PB13 = SPI2_SCK (AF5, input)      PB15 = SPI2_MOSI (AF5, input)          */
static void spi2_capture_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_SPI2EN;
    (void)RCC->APB1ENR;

    GPIOB->MODER   &= ~((3u << (13u * 2u)) | (3u << (15u * 2u)));
    GPIOB->MODER   |=  ((2u << (13u * 2u)) | (2u << (15u * 2u)));  /* 10 = AF */
    GPIOB->OSPEEDR |=  ((3u << (13u * 2u)) | (3u << (15u * 2u)));

    GPIOB->PUPDR   &= ~((3u << (13u * 2u)) | (3u << (15u * 2u)));
    GPIOB->PUPDR   |=   (2u << (13u * 2u));    /* SCK  pull-DOWN: idles low  */
    GPIOB->PUPDR   |=   (1u << (15u * 2u));    /* MOSI pull-UP: UART idles hi */

    GPIOB->AFR[1] &= ~((0xFu << ((13u - 8u) * 4u)) | (0xFu << ((15u - 8u) * 4u)));
    GPIOB->AFR[1] |=  ((5u   << ((13u - 8u) * 4u)) | (5u   << ((15u - 8u) * 4u)));

    SPI2->CR1 = 0u;
    SPI2->CR2 = 0u;
    SPI2->CR1 = SPI_CR1_CPHA      |   /* CPHA = 1, CPOL = 0                  */
                SPI_CR1_LSBFIRST  |   /* the USART sends the LSB first       */
                SPI_CR1_SSM;          /* SSM = 1, SSI = 0 -> always selected */
    SPI2->CR1 |= SPI_CR1_SPE;
}

/* Non-blocking read of one captured byte. */
static uint32_t spi2_get(uint8_t *b)
{
    if (SPI2->SR & SPI_SR_OVR) {                 /* clear a stale overrun    */
        (void)SPI2->DR; (void)SPI2->SR;
    }
    if (SPI2->SR & SPI_SR_RXNE) {
        *b = *(volatile uint8_t *)&SPI2->DR;
        return 1u;
    }
    return 0u;
}

/*================================= main ====================================*/
int main(void)
{
    uint8_t  byte, cmd = 0u;
    uint32_t state = 0u;

    clock_init_hsi_16mhz();
    systick_init();
    led_init();
    ackpin_init();
    spi2_capture_init();

    led_on(); delay_ms(300u); led_off();          /* "slave alive" signal    */

    for (;;) {
        if (!spi2_get(&byte)) { continue; }

        switch (state) {
        case 0u:
            if (byte == CMD_SYNC) { state = 1u; }
            break;

        case 1u:
            cmd   = byte;
            state = 2u;
            break;

        default:
            if ((uint8_t)(cmd ^ 0xFFu) == byte &&
                (cmd == CMD_SHORT || cmd == CMD_LONG)) {
                ack_pulse();                       /* tell the master "got it" */
                run_pattern(cmd);
            }
            state = 0u;
            break;
        }
    }
}

/*=============================================================================
 *  APPENDIX - OPTION B : receive with the USART instead of SPI
 *  ---------------------------------------------------------------------------
 *  If your lab only requires that the CK line be *generated and observed*
 *  (e.g. on an oscilloscope) you may capture the data asynchronously instead.
 *  Wire master PA9 -> slave PA10 (keep PA8 -> a scope probe), then replace
 *  spi2_capture_init()/spi2_get() with:
 *
 *      static void usart1_rx_init(void)
 *      {
 *          RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
 *          RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
 *          GPIOA->MODER  &= ~(3u << (10u * 2u));
 *          GPIOA->MODER  |=  (2u << (10u * 2u));
 *          GPIOA->PUPDR  &= ~(3u << (10u * 2u));
 *          GPIOA->PUPDR  |=  (1u << (10u * 2u));
 *          GPIOA->AFR[1] &= ~(0xFu << ((10u - 8u) * 4u));
 *          GPIOA->AFR[1] |=  (7u   << ((10u - 8u) * 4u));
 *          USART1->CR1 = 0u; USART1->CR2 = 0u; USART1->CR3 = 0u;
 *          USART1->BRR = 1667u;
 *          USART1->CR1 = USART_CR1_RE | USART_CR1_UE;
 *      }
 *      static uint32_t usart1_get(uint8_t *b)
 *      {
 *          if (USART1->SR & USART_SR_ORE) { (void)USART1->SR; (void)USART1->DR; }
 *          if (USART1->SR & USART_SR_RXNE) { *b = (uint8_t)USART1->DR; return 1u; }
 *          return 0u;
 *      }
 *===========================================================================*/
