/*=============================================================================
 *  EXPERIMENT 1 : UART (USART1, ASYNCHRONOUS)               ---  S L A V E  ---
 *  Board  : NUCLEO-F446RE   (STM32F446RET6, Cortex-M4)
 *  Style  : 100 % bare-metal CMSIS register programming - no HAL, no CubeMX.
 *
 *  FUNCTION
 *      Continuously parses the 3-byte frame [0xAA][cmd][~cmd] on USART1.
 *      When a valid frame arrives it immediately answers ACK (0x5A) so the
 *      master is not blocked, and then plays the LD2 (PA5) blink pattern:
 *
 *          CMD_SHORT (0xA1)  ->  3 blinks, 150 ms ON / 150 ms OFF
 *                                (LED turns on every 300 ms)
 *          CMD_LONG  (0xA2)  ->  3 blinks, 1000 ms ON / 1000 ms OFF
 *                                (LED turns on every 2000 ms = 2 s spacing)
 *
 *  WIRING (see master file - the two boards are wired TX<->RX crossed, and
 *  the two grounds MUST be joined).
 *===========================================================================*/

#include "stm32f446xx.h"
#include <stdint.h>

#define LED_PIN          5u        /* PA5 - LD2 green user LED               */

#define CMD_SYNC         0xAAu
#define CMD_SHORT        0xA1u
#define CMD_LONG         0xA2u
#define ACK_BYTE         0x5Au

/* ---- formal blink specification (edit here to retune the experiment) ---- */
#define SHORT_ON_MS      150u
#define SHORT_OFF_MS     150u
#define SHORT_REPEAT     3u
#define LONG_ON_MS       1000u
#define LONG_OFF_MS      1000u     /* 1000 + 1000 = 2000 ms LED-to-LED period */
#define LONG_REPEAT      3u

/*======================= 1. CLOCK : HSI 16 MHz, no PLL =====================*/
static void clock_init_hsi_16mhz(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) { }

    FLASH->ACR = FLASH_ACR_LATENCY_0WS;

    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

/*========================= 2. SysTick 1 ms time base =======================*/
static volatile uint32_t s_ticks;

void SysTick_Handler(void) { s_ticks++; }

static void systick_init(void)
{
    SysTick->LOAD = 16000u - 1u;
    SysTick->VAL  = 0u;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
}
static uint32_t millis(void) { return s_ticks; }
static void delay_ms(uint32_t ms)
{
    uint32_t t0 = s_ticks;
    while ((uint32_t)(s_ticks - t0) < ms) { __NOP(); }
}

/*============================ 3. On-board LD2 ==============================*/
static void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;

    GPIOA->MODER   &= ~(3u << (LED_PIN * 2u));
    GPIOA->MODER   |=  (1u << (LED_PIN * 2u));
    GPIOA->OTYPER  &= ~(1u << LED_PIN);
    GPIOA->OSPEEDR &= ~(3u << (LED_PIN * 2u));
    GPIOA->PUPDR   &= ~(3u << (LED_PIN * 2u));
    GPIOA->BSRR     =  (1u << (LED_PIN + 16u));
}
static void led_on (void) { GPIOA->BSRR = (1u << LED_PIN); }
static void led_off(void) { GPIOA->BSRR = (1u << (LED_PIN + 16u)); }

/* The behaviour that the whole experiment is about. */
static void run_pattern(uint8_t cmd)
{
    uint32_t i, n, on, off;

    if (cmd == CMD_LONG) { n = LONG_REPEAT;  on = LONG_ON_MS;  off = LONG_OFF_MS;  }
    else                 { n = SHORT_REPEAT; on = SHORT_ON_MS; off = SHORT_OFF_MS; }

    for (i = 0u; i < n; i++) {
        led_on();  delay_ms(on);
        led_off(); delay_ms(off);
    }
}

/*============================== 4. USART1 ==================================*/
static void usart1_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
    (void)RCC->APB2ENR;

    GPIOA->MODER   &= ~((3u << (9u * 2u)) | (3u << (10u * 2u)));
    GPIOA->MODER   |=  ((2u << (9u * 2u)) | (2u << (10u * 2u)));
    GPIOA->OTYPER  &= ~((1u << 9u) | (1u << 10u));
    GPIOA->OSPEEDR |=  ((3u << (9u * 2u)) | (3u << (10u * 2u)));
    GPIOA->PUPDR   &= ~((3u << (9u * 2u)) | (3u << (10u * 2u)));
    GPIOA->PUPDR   |=  ((1u << (9u * 2u)) | (1u << (10u * 2u)));

    GPIOA->AFR[1] &= ~((0xFu << ((9u  - 8u) * 4u)) | (0xFu << ((10u - 8u) * 4u)));
    GPIOA->AFR[1] |=  ((7u   << ((9u  - 8u) * 4u)) | (7u   << ((10u - 8u) * 4u)));

    USART1->CR1 = 0u;
    USART1->CR2 = 0u;
    USART1->CR3 = 0u;
    USART1->BRR = 1667u;                 /* 9600 Bd @ 16 MHz - must match!  */
    USART1->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static void usart1_write(uint8_t b)
{
    while ((USART1->SR & USART_SR_TXE) == 0u) { }
    USART1->DR = (uint32_t)b;
}
static void usart1_flush(void)
{
    while ((USART1->SR & USART_SR_TC) == 0u) { }
}
static uint32_t usart1_read(uint8_t *b, uint32_t timeout_ms)
{
    uint32_t t0 = millis();
    while ((uint32_t)(millis() - t0) < timeout_ms) {
        if (USART1->SR & USART_SR_RXNE) { *b = (uint8_t)USART1->DR; return 1u; }
        if (USART1->SR & USART_SR_ORE)  { (void)USART1->SR; (void)USART1->DR; }
    }
    return 0u;
}

/*================================= main ====================================*/
int main(void)
{
    uint8_t  byte, cmd = 0u;
    uint32_t state = 0u;             /* 0 = wait sync, 1 = wait cmd, 2 = chk */

    clock_init_hsi_16mhz();
    systick_init();
    led_init();
    usart1_init();

    led_on(); delay_ms(300u); led_off();          /* "slave alive" signal    */

    for (;;) {
        if (!usart1_read(&byte, 10u)) { continue; }

        switch (state) {
        case 0u:                                   /* hunting for the sync   */
            if (byte == CMD_SYNC) { state = 1u; }
            break;

        case 1u:                                   /* command byte           */
            cmd   = byte;
            state = 2u;
            break;

        default:                                   /* checksum byte          */
            if ((uint8_t)(cmd ^ 0xFFu) == byte &&
                (cmd == CMD_SHORT || cmd == CMD_LONG)) {
                usart1_write(ACK_BYTE);            /* answer first ...       */
                usart1_flush();
                run_pattern(cmd);                  /* ... then blink         */
            }
            state = 0u;
            break;
        }
    }
}
