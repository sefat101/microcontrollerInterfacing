/* EXP 1  UART (USART1 async, 9600 8N1)  ---  SLAVE  ---  NUCLEO-F446RE
 * Wiring : PA10 (CN10-33) <- master PA9 (CN10-21)
 *          GND  (CN10-20) <- master GND (CN10-20)
 * 'S' -> 3 blinks 150 ms      'L' -> 3 blinks 1000 ms (2 s spacing)   */

#include "stm32f446xx.h"

static void delay_ms(uint32_t ms)
{
    SysTick->LOAD = 16000 - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;
    while (ms--) while (!(SysTick->CTRL & (1 << 16)));
    SysTick->CTRL = 0;
}

static void blink(uint32_t d)                   /* d = half period      */
{
    for (int i = 0; i < 3; i++) {
        GPIOA->ODR |=  (1 << 5);  delay_ms(d);
        GPIOA->ODR &= ~(1 << 5);  delay_ms(d);
    }
}

int main(void)
{
    RCC->AHB1ENR |= (1 << 0);                   /* GPIOA                */
    RCC->APB2ENR |= (1 << 4);                   /* USART1               */

    GPIOA->MODER  |= (1 << 10);                 /* PA5  output   (LD2)  */
    GPIOA->MODER  |= (2 << 20);                 /* PA10 alternate       */
    GPIOA->AFR[1] |= (7 << 8);                  /* PA10 AF7 = USART1_RX */

    USART1->BRR = 1667;                         /* must match master    */
    USART1->CR1 = (1 << 2) | (1 << 13);         /* RE, UE               */

    while (1)
        if (USART1->SR & (1 << 5))              /* RXNE                 */
            blink(USART1->DR == 'L' ? 1000 : 150);
}
