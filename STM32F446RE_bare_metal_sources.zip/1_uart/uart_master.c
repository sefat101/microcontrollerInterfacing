/* EXP 1  UART (USART1 async, 9600 8N1)  ---  MASTER  ---  NUCLEO-F446RE
 * Wiring : PA9 (CN10-21) -> slave PA10 (CN10-33)
 *          GND (CN10-20) -> slave GND  (CN10-20)
 * B1 = PC13 (on board)   LD2 = PA5 (on board)                          */

#include "stm32f446xx.h"

static void delay_ms(uint32_t ms)
{
    SysTick->LOAD = 16000 - 1;                  /* 1 ms at 16 MHz HSI   */
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;                          /* core clock, enable   */
    while (ms--) while (!(SysTick->CTRL & (1 << 16)));   /* COUNTFLAG   */
    SysTick->CTRL = 0;
}

int main(void)
{
    uint32_t t;

    RCC->AHB1ENR |= (1 << 0) | (1 << 2);        /* GPIOA, GPIOC         */
    RCC->APB2ENR |= (1 << 4);                   /* USART1               */

    GPIOC->PUPDR  |= (1 << 26);                 /* PC13 pull-up  (B1)   */
    GPIOA->MODER  |= (1 << 10);                 /* PA5  output   (LD2)  */
    GPIOA->MODER  |= (2 << 18);                 /* PA9  alternate       */
    GPIOA->AFR[1] |= (7 << 4);                  /* PA9  AF7 = USART1_TX */

    USART1->BRR = 1667;                         /* 16000000 / 9600      */
    USART1->CR1 = (1 << 3) | (1 << 13);         /* TE, UE               */

    while (1) {
        if (GPIOC->IDR & (1 << 13)) continue;   /* B1 released -> wait  */

        t = 0;                                  /* measure press length */
        while (!(GPIOC->IDR & (1 << 13))) { delay_ms(10); t += 10; }

        while (!(USART1->SR & (1 << 7)));       /* TXE                  */
        USART1->DR = (t >= 1000) ? 'L' : 'S';

        GPIOA->ODR |=  (1 << 5);                /* LD2 = command sent   */
        delay_ms(100);
        GPIOA->ODR &= ~(1 << 5);
    }
}
