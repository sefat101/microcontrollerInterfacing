/*=============================================================================
 *  EXPERIMENT 1 : UART (USART1, ASYNCHRONOUS)              ---  M A S T E R  ---
 *  Board  : NUCLEO-F446RE   (STM32F446RET6, Cortex-M4)
 *  Style  : 100 % bare-metal CMSIS register programming - no HAL, no CubeMX.
 *           Everything (clock tree, GPIO, USART, SysTick) is configured here.
 *
 *  FUNCTION
 *      B1 (blue user button, PC13) is sampled and de-bounced in software.
 *      The press LENGTH is measured with a 1 ms SysTick time base:
 *          press <  1000 ms  ->  transmit CMD_SHORT (0xA1)
 *          press >= 1000 ms  ->  transmit CMD_LONG  (0xA2)
 *      Frame sent : [0xAA sync][cmd][~cmd checksum]
 *      The slave answers with ACK (0x5A); the master then flashes LD2 green
 *      (and the optional external RGB LED green = OK / red = no answer).
 *
 *  WIRING (master -> slave)
 *      PA9  USART1_TX  (CN10-21 / D8)  ->  PA10 USART1_RX  (CN10-33 / D2)
 *      PA10 USART1_RX  (CN10-33 / D2)  <-  PA9  USART1_TX  (CN10-21 / D8)
 *      GND             (CN10-20)       <-> GND             (CN10-20)
 *
 *  Optional RGB status LED on the MASTER (common cathode + 3 x 330 R):
 *      PC0 = RED (CN7-38), PC1 = GREEN (CN7-36), PC2 = BLUE (CN7-35),
 *      common cathode -> GND (CN7-20).  Set USE_RGB to 0 if not fitted.
 *===========================================================================*/

#include "stm32f446xx.h"
#include <stdint.h>

/*--------------------------- user configuration ---------------------------*/
#define USE_RGB          1u        /* 1 = external RGB LED fitted on PC0/1/2 */
#define RGB_COMMON_CATHODE 1u      /* 0 if you use a common-ANODE RGB LED    */

#define LED_PIN          5u        /* PA5  - LD2 green user LED              */
#define BTN_PIN          13u       /* PC13 - B1  blue user button (active 0) */

#define CMD_SYNC         0xAAu
#define CMD_SHORT        0xA1u
#define CMD_LONG         0xA2u
#define ACK_BYTE         0x5Au

#define T_DEBOUNCE_MS    20u       /* mechanical bounce window               */
#define T_LONG_MS        1000u     /* short / long press decision threshold  */
#define T_ACK_MS         500u      /* how long we wait for the slave's ACK   */

/*======================= 1. CLOCK : HSI 16 MHz, no PLL =====================*/
/* Deterministic and simple: SYSCLK = HCLK = PCLK1 = PCLK2 = 16 MHz.         */
static void clock_init_hsi_16mhz(void)
{
    RCC->CR |= RCC_CR_HSION;                     /* start internal 16 MHz RC */
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) { }

    FLASH->ACR = FLASH_ACR_LATENCY_0WS;          /* 16 MHz @3.3 V -> 0 WS    */

    RCC->CFGR &= ~RCC_CFGR_SW;                   /* SW = 00 -> HSI is SYSCLK */
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
    /* AHB /1, APB1 /1, APB2 /1  ->  PCLK1 = PCLK2 = 16 MHz                  */
}

/*========================= 2. SysTick 1 ms time base =======================*/
static volatile uint32_t s_ticks;

void SysTick_Handler(void) { s_ticks++; }        /* weak symbol in startup_*.s */

static void systick_init(void)
{
    SysTick->LOAD = 16000u - 1u;                 /* 16 MHz / 16000 = 1 kHz   */
    SysTick->VAL  = 0u;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
}
static uint32_t millis(void) { return s_ticks; }
static void delay_ms(uint32_t ms)
{
    uint32_t t0 = s_ticks;
    while ((uint32_t)(s_ticks - t0) < ms) { __NOP(); }
}

/*============================ 3. On-board LD2 ==============================*/
static void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;                          /* clock-enable read-back   */

    GPIOA->MODER   &= ~(3u << (LED_PIN * 2u));
    GPIOA->MODER   |=  (1u << (LED_PIN * 2u));   /* 01 = general output      */
    GPIOA->OTYPER  &= ~(1u << LED_PIN);          /* push-pull                */
    GPIOA->OSPEEDR &= ~(3u << (LED_PIN * 2u));   /* low speed is fine        */
    GPIOA->PUPDR   &= ~(3u << (LED_PIN * 2u));
    GPIOA->BSRR     =  (1u << (LED_PIN + 16u));  /* start OFF                */
}
static void led_on (void) { GPIOA->BSRR = (1u << LED_PIN); }
static void led_off(void) { GPIOA->BSRR = (1u << (LED_PIN + 16u)); }

/*============================ 4. On-board B1 ===============================*/
static void button_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;

    GPIOC->MODER &= ~(3u << (BTN_PIN * 2u));     /* 00 = input               */
    GPIOC->PUPDR &= ~(3u << (BTN_PIN * 2u));
    GPIOC->PUPDR |=  (1u << (BTN_PIN * 2u));     /* 01 = internal pull-up    */
}
static uint32_t button_down(void)
{
    return ((GPIOC->IDR & (1u << BTN_PIN)) == 0u);   /* B1 is active LOW     */
}

/* Blocking, de-bounced press capture.
 * Returns 0 (nothing), CMD_SHORT or CMD_LONG and reports the press length. */
static uint8_t button_capture(uint32_t *press_ms)
{
    uint32_t t0, d;

    if (!button_down())            return 0u;
    delay_ms(T_DEBOUNCE_MS);
    if (!button_down())            return 0u;    /* it was only a bounce     */

    t0 = millis();
    while (button_down()) { __NOP(); }           /* wait for the release     */
    delay_ms(T_DEBOUNCE_MS);                     /* de-bounce the release    */

    d = millis() - t0;
    if (press_ms != 0) { *press_ms = d; }
    return (d >= T_LONG_MS) ? CMD_LONG : CMD_SHORT;
}

/*======================== 5. Optional RGB indicator ========================*/
static void rgb_init(void)
{
#if USE_RGB
    uint32_t p;
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;
    for (p = 0u; p <= 2u; p++) {                 /* PC0 = R, PC1 = G, PC2 = B */
        GPIOC->MODER  &= ~(3u << (p * 2u));
        GPIOC->MODER  |=  (1u << (p * 2u));
        GPIOC->OTYPER &= ~(1u << p);
        GPIOC->PUPDR  &= ~(3u << (p * 2u));
    }
#endif
}
static void rgb_set(uint32_t r, uint32_t g, uint32_t b)
{
#if USE_RGB
  #if RGB_COMMON_CATHODE
    GPIOC->BSRR = (r ? (1u << 0) : (1u << 16)) |
                  (g ? (1u << 1) : (1u << 17)) |
                  (b ? (1u << 2) : (1u << 18));
  #else                                          /* common anode: inverted   */
    GPIOC->BSRR = (r ? (1u << 16) : (1u << 0)) |
                  (g ? (1u << 17) : (1u << 1)) |
                  (b ? (1u << 18) : (1u << 2));
  #endif
#else
    (void)r; (void)g; (void)b;
#endif
}

/* Green + one long LD2 flash = ACK received.  Red + triple flash = no ACK.  */
static void master_indicate(uint32_t ok)
{
    uint32_t i;
    if (ok) {
        rgb_set(0u, 1u, 0u);
        led_on();  delay_ms(250u); led_off();
    } else {
        rgb_set(1u, 0u, 0u);
        for (i = 0u; i < 3u; i++) { led_on(); delay_ms(60u); led_off(); delay_ms(60u); }
    }
    rgb_set(0u, 0u, 0u);
}

/*============================== 6. USART1 ==================================*/
/*  PA9  = USART1_TX (AF7)     PA10 = USART1_RX (AF7)
 *  9600 baud, 8 data bits, no parity, 1 stop bit, oversampling by 16.
 *  BRR = fPCLK2 / baud = 16 000 000 / 9600 = 1666.67  ->  1667 (0x683)     */
static void usart1_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    RCC->APB2ENR |= RCC_APB2ENR_USART1EN;
    (void)RCC->APB2ENR;

    GPIOA->MODER   &= ~((3u << (9u * 2u)) | (3u << (10u * 2u)));
    GPIOA->MODER   |=  ((2u << (9u * 2u)) | (2u << (10u * 2u)));   /* 10 = AF */
    GPIOA->OTYPER  &= ~((1u << 9u) | (1u << 10u));                 /* push-pull */
    GPIOA->OSPEEDR |=  ((3u << (9u * 2u)) | (3u << (10u * 2u)));   /* high sp. */
    GPIOA->PUPDR   &= ~((3u << (9u * 2u)) | (3u << (10u * 2u)));
    GPIOA->PUPDR   |=  ((1u << (9u * 2u)) | (1u << (10u * 2u)));   /* pull-up  */

    /* AFR[1] = AFRH, 4 bits per pin, pin n uses bits (n-8)*4 */
    GPIOA->AFR[1] &= ~((0xFu << ((9u  - 8u) * 4u)) | (0xFu << ((10u - 8u) * 4u)));
    GPIOA->AFR[1] |=  ((7u   << ((9u  - 8u) * 4u)) | (7u   << ((10u - 8u) * 4u)));

    USART1->CR1 = 0u;                 /* disable while (re)configuring        */
    USART1->CR2 = 0u;                 /* 1 stop bit, no clock output          */
    USART1->CR3 = 0u;                 /* no flow control, no DMA              */
    USART1->BRR = 1667u;              /* 9600 Bd @ 16 MHz                     */
    USART1->CR1 = USART_CR1_TE | USART_CR1_RE | USART_CR1_UE;
}

static void usart1_write(uint8_t b)
{
    while ((USART1->SR & USART_SR_TXE) == 0u) { }   /* TDR empty ?            */
    USART1->DR = (uint32_t)b;
}
static void usart1_flush(void)
{
    while ((USART1->SR & USART_SR_TC) == 0u) { }    /* last stop bit gone     */
}
/* Returns 1 and the byte, or 0 on timeout. */
static uint32_t usart1_read(uint8_t *b, uint32_t timeout_ms)
{
    uint32_t t0 = millis();
    while ((uint32_t)(millis() - t0) < timeout_ms) {
        if (USART1->SR & USART_SR_RXNE) { *b = (uint8_t)USART1->DR; return 1u; }
        if (USART1->SR & USART_SR_ORE)  { (void)USART1->SR; (void)USART1->DR; }
    }
    return 0u;
}

/*================================= main ====================================*/
int main(void)
{
    uint8_t  cmd, ack;
    uint32_t press_ms, ok;

    clock_init_hsi_16mhz();
    systick_init();
    led_init();
    button_init();
    rgb_init();
    usart1_init();

    rgb_set(0u, 0u, 1u); led_on(); delay_ms(300u); led_off(); rgb_set(0u,0u,0u);

    for (;;) {
        press_ms = 0u;
        cmd = button_capture(&press_ms);
        if (cmd == 0u) { continue; }

        rgb_set(0u, 0u, 1u);                      /* blue = transmitting     */

        usart1_write(CMD_SYNC);
        usart1_write(cmd);
        usart1_write((uint8_t)(cmd ^ 0xFFu));     /* checksum                */
        usart1_flush();

        rgb_set(0u, 0u, 0u);

        ack = 0u;
        ok  = usart1_read(&ack, T_ACK_MS) && (ack == ACK_BYTE);
        master_indicate(ok);
    }
}
