/* EXP 3  SPI2 (mode 0)  ---  SLAVE  ---  NUCLEO-F446RE
 * A slave has no baud-rate field: the master's SCK clocks it.
 * NSS is hardware here (SSM = 0), so PB12 must be wired.
 * Wiring : PB12 (CN10-16), PB13 (CN10-30), PB15 (CN10-26), GND
 *          all straight through to the same pins on the master.       */

#include "stm32f446xx.h"

static void delay_ms(uint32_t ms)
{
    SysTick->LOAD = 16000 - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;
    while (ms--) while (!(SysTick->CTRL & (1 << 16)));
    SysTick->CTRL = 0;
}

static void blink(uint32_t d)
{
    for (int i = 0; i < 3; i++) {
        GPIOA->ODR |=  (1 << 5);  delay_ms(d);
        GPIOA->ODR &= ~(1 << 5);  delay_ms(d);
    }
}

int main(void)
{
    RCC->AHB1ENR |= (1 << 0) | (1 << 1);        /* GPIOA, GPIOB         */
    RCC->APB1ENR |= (1 << 14);                  /* SPI2                 */

    GPIOA->MODER  |= (1 << 10);                 /* PA5 output    (LD2)  */
    GPIOB->MODER  |= (2 << 24) | (2 << 26) | (2 << 30);  /* PB12,13,15  */
    GPIOB->AFR[1] |= (5 << 16) | (5 << 20) | (5 << 28);  /* AF5 = SPI2  */

    SPI2->CR1 = (1 << 6);                       /* SPE only: MSTR = 0,  */
                                                /* mode 0, MSB, HW NSS  */
    while (1)
        if (SPI2->SR & (1 << 0))                /* RXNE                 */
            blink((uint8_t)SPI2->DR == 'L' ? 1000 : 150);
}
