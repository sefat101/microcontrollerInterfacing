/*=============================================================================
 *  EXPERIMENT 3 : SPI (SPI2, FULL DUPLEX)                   ---  S L A V E  ---
 *  Board  : NUCLEO-F446RE   (STM32F446RET6, Cortex-M4)
 *  Style  : 100 % bare-metal CMSIS register programming - no HAL, no CubeMX.
 *
 *  BUS SETTINGS  (must be identical to the master except for MSTR)
 *      MSTR = 0, CPOL = 0, CPHA = 0, MSB first, 8-bit frames.
 *      NSS is HARDWARE managed here: SSM = 0 and PB12 is configured as AF5,
 *      so the peripheral only shifts while the master holds PB12 low.
 *      A slave has no baud-rate register - the master's SCK sets the speed.
 *
 *  PROTOCOL
 *      Receives [0xAA][cmd][~cmd] and pre-loads ACK (0x5A) into the transmit
 *      register so that it is shifted out during the master's 4th (dummy)
 *      byte.  Only after the whole 4-byte frame has gone by does it drive the
 *      blink pattern, so the SPI bus is never held up.
 *
 *  WIRING (straight through)
 *      PB12 NSS  (CN10-16) <- master PB12
 *      PB13 SCK  (CN10-30) <- master PB13
 *      PB14 MISO (CN10-28) -> master PB14
 *      PB15 MOSI (CN10-26) <- master PB15
 *      GND       (CN10-20) <-> master GND
 *
 *  BLINK SPECIFICATION
 *      CMD_SHORT (0xA1) -> 3 blinks, 150 ms ON / 150 ms OFF (300 ms spacing)
 *      CMD_LONG  (0xA2) -> 3 blinks, 1000 ms ON / 1000 ms OFF (2 s spacing)
 *===========================================================================*/

#include "stm32f446xx.h"
#include <stdint.h>

#define LED_PIN          5u        /* PA5 - LD2 green user LED               */

#define CMD_SYNC         0xAAu
#define CMD_SHORT        0xA1u
#define CMD_LONG         0xA2u
#define ACK_BYTE         0x5Au

#define SHORT_ON_MS      150u
#define SHORT_OFF_MS     150u
#define SHORT_REPEAT     3u
#define LONG_ON_MS       1000u
#define LONG_OFF_MS      1000u
#define LONG_REPEAT      3u

/*======================= 1. CLOCK : HSI 16 MHz, no PLL =====================*/
static void clock_init_hsi_16mhz(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) { }

    FLASH->ACR = FLASH_ACR_LATENCY_0WS;

    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

/*========================= 2. SysTick 1 ms time base =======================*/
static volatile uint32_t s_ticks;

void SysTick_Handler(void) { s_ticks++; }

static void systick_init(void)
{
    SysTick->LOAD = 16000u - 1u;
    SysTick->VAL  = 0u;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
}
static void delay_ms(uint32_t ms)
{
    uint32_t t0 = s_ticks;
    while ((uint32_t)(s_ticks - t0) < ms) { __NOP(); }
}

/*============================ 3. On-board LD2 ==============================*/
static void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;

    GPIOA->MODER   &= ~(3u << (LED_PIN * 2u));
    GPIOA->MODER   |=  (1u << (LED_PIN * 2u));
    GPIOA->OTYPER  &= ~(1u << LED_PIN);
    GPIOA->OSPEEDR &= ~(3u << (LED_PIN * 2u));
    GPIOA->PUPDR   &= ~(3u << (LED_PIN * 2u));
    GPIOA->BSRR     =  (1u << (LED_PIN + 16u));
}
static void led_on (void) { GPIOA->BSRR = (1u << LED_PIN); }
static void led_off(void) { GPIOA->BSRR = (1u << (LED_PIN + 16u)); }

static void run_pattern(uint8_t cmd)
{
    uint32_t i, n, on, off;

    if (cmd == CMD_LONG) { n = LONG_REPEAT;  on = LONG_ON_MS;  off = LONG_OFF_MS;  }
    else                 { n = SHORT_REPEAT; on = SHORT_ON_MS; off = SHORT_OFF_MS; }

    for (i = 0u; i < n; i++) {
        led_on();  delay_ms(on);
        led_off(); delay_ms(off);
    }
}

/*========================== 4. SPI2 in SLAVE mode ==========================*/
static void spi2_slave_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_SPI2EN;
    (void)RCC->APB1ENR;

    /* PB12 = NSS, PB13 = SCK, PB14 = MISO, PB15 = MOSI - all AF5           */
    GPIOB->MODER   &= ~((3u << (12u*2u)) | (3u << (13u*2u)) |
                        (3u << (14u*2u)) | (3u << (15u*2u)));
    GPIOB->MODER   |=  ((2u << (12u*2u)) | (2u << (13u*2u)) |
                        (2u << (14u*2u)) | (2u << (15u*2u)));
    GPIOB->OTYPER  &= ~((1u << 12u) | (1u << 13u) | (1u << 14u) | (1u << 15u));
    GPIOB->OSPEEDR |=  ((3u << (12u*2u)) | (3u << (13u*2u)) |
                        (3u << (14u*2u)) | (3u << (15u*2u)));
    GPIOB->PUPDR   &= ~((3u << (12u*2u)) | (3u << (13u*2u)) |
                        (3u << (14u*2u)) | (3u << (15u*2u)));
    GPIOB->PUPDR   |=   (1u << (12u*2u));    /* NSS pull-up: idle = not sel. */
    GPIOB->PUPDR   |=   (2u << (13u*2u));    /* SCK pull-down: CPOL = 0      */

    GPIOB->AFR[1] &= ~((0xFu << ((12u-8u)*4u)) | (0xFu << ((13u-8u)*4u)) |
                       (0xFu << ((14u-8u)*4u)) | (0xFu << ((15u-8u)*4u)));
    GPIOB->AFR[1] |=  ((5u   << ((12u-8u)*4u)) | (5u   << ((13u-8u)*4u)) |
                       (5u   << ((14u-8u)*4u)) | (5u   << ((15u-8u)*4u)));

    SPI2->CR1 = 0u;                  /* MSTR = 0, SSM = 0 -> hardware NSS   */
    SPI2->CR2 = 0u;                  /* CPOL = 0, CPHA = 0, MSB, 8-bit      */
    SPI2->CR1 |= SPI_CR1_SPE;
}

static uint32_t spi2_get(uint8_t *b)
{
    if (SPI2->SR & SPI_SR_OVR) { (void)SPI2->DR; (void)SPI2->SR; }
    if (SPI2->SR & SPI_SR_RXNE) {
        *b = *(volatile uint8_t *)&SPI2->DR;
        return 1u;
    }
    return 0u;
}
static void spi2_load_reply(uint8_t b)
{
    if (SPI2->SR & SPI_SR_TXE) { *(volatile uint8_t *)&SPI2->DR = b; }
}

/*================================= main ====================================*/
int main(void)
{
    uint8_t  byte, cmd = 0u, pending = 0u;
    uint32_t state = 0u;

    clock_init_hsi_16mhz();
    systick_init();
    led_init();
    spi2_slave_init();

    led_on(); delay_ms(300u); led_off();          /* "slave alive" signal    */

    for (;;) {
        if (!spi2_get(&byte)) { continue; }

        switch (state) {
        case 0u:
            if (byte == CMD_SYNC) { state = 1u; }
            break;

        case 1u:
            cmd   = byte;
            state = 2u;
            break;

        case 2u:                                   /* checksum byte          */
            if ((uint8_t)(cmd ^ 0xFFu) == byte &&
                (cmd == CMD_SHORT || cmd == CMD_LONG)) {
                spi2_load_reply(ACK_BYTE);         /* goes out on byte 4     */
                pending = cmd;
                state   = 3u;
            } else {
                state = 0u;
            }
            break;

        default:                                   /* the dummy 4th byte     */
            run_pattern(pending);                  /* ACK has been shifted   */
            pending = 0u;
            state   = 0u;
            break;
        }
    }
}
