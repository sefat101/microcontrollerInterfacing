/*=============================================================================
 *  EXPERIMENT 3 : SPI (SPI2, FULL DUPLEX)                  ---  M A S T E R  ---
 *  Board  : NUCLEO-F446RE   (STM32F446RET6, Cortex-M4)
 *  Style  : 100 % bare-metal CMSIS register programming - no HAL, no CubeMX.
 *
 *  WHY SPI2 AND NOT SPI1
 *      SPI1_SCK is multiplexed with PA5, which is the on-board LD2 LED.  Using
 *      SPI2 (PB12..PB15) keeps LD2 free for the visual indication.
 *
 *  BUS SETTINGS
 *      Mode 0 : CPOL = 0 (clock idles low), CPHA = 0 (sample on 1st edge)
 *      MSB first, 8-bit frames, BR = 101b -> fPCLK1 / 64 = 250 kHz
 *      (deliberately slow so that ordinary jumper wires work reliably)
 *      NSS is driven by software from PB12 as a plain GPIO output.
 *
 *  TRANSACTION (4 bytes, one chip-select frame)
 *      byte 0  0xAA sync            slave returns don't-care
 *      byte 1  cmd  (0xA1 / 0xA2)   slave returns don't-care
 *      byte 2  ~cmd checksum        slave returns don't-care
 *      byte 3  0x00 dummy           slave returns ACK = 0x5A
 *
 *  WIRING (straight through - SPI is not crossed like UART!)
 *      PB12 NSS  (CN10-16) -> PB12 NSS  (CN10-16)
 *      PB13 SCK  (CN10-30) -> PB13 SCK  (CN10-30)
 *      PB14 MISO (CN10-28) <- PB14 MISO (CN10-28)
 *      PB15 MOSI (CN10-26) -> PB15 MOSI (CN10-26)
 *      GND       (CN10-20) <-> GND      (CN10-20)
 *
 *  Optional RGB status LED on the MASTER (common cathode + 3 x 330 R):
 *      PC0 = RED (CN7-38), PC1 = GREEN (CN7-36), PC2 = BLUE (CN7-35).
 *===========================================================================*/

#include "stm32f446xx.h"
#include <stdint.h>

/*--------------------------- user configuration ---------------------------*/
#define USE_RGB            1u
#define RGB_COMMON_CATHODE 1u

#define LED_PIN          5u        /* PA5  - LD2 green user LED              */
#define BTN_PIN          13u       /* PC13 - B1  blue user button            */
#define NSS_PIN          12u       /* PB12 - software chip select            */

#define CMD_SYNC         0xAAu
#define CMD_SHORT        0xA1u
#define CMD_LONG         0xA2u
#define ACK_BYTE         0x5Au

#define T_DEBOUNCE_MS    20u
#define T_LONG_MS        1000u

/*======================= 1. CLOCK : HSI 16 MHz, no PLL =====================*/
static void clock_init_hsi_16mhz(void)
{
    RCC->CR |= RCC_CR_HSION;
    while ((RCC->CR & RCC_CR_HSIRDY) == 0u) { }

    FLASH->ACR = FLASH_ACR_LATENCY_0WS;

    RCC->CFGR &= ~RCC_CFGR_SW;
    while ((RCC->CFGR & RCC_CFGR_SWS) != RCC_CFGR_SWS_HSI) { }

    RCC->CFGR &= ~(RCC_CFGR_HPRE | RCC_CFGR_PPRE1 | RCC_CFGR_PPRE2);
}

/*========================= 2. SysTick 1 ms time base =======================*/
static volatile uint32_t s_ticks;

void SysTick_Handler(void) { s_ticks++; }

static void systick_init(void)
{
    SysTick->LOAD = 16000u - 1u;
    SysTick->VAL  = 0u;
    SysTick->CTRL = SysTick_CTRL_CLKSOURCE_Msk |
                    SysTick_CTRL_TICKINT_Msk   |
                    SysTick_CTRL_ENABLE_Msk;
}
static uint32_t millis(void) { return s_ticks; }
static void delay_ms(uint32_t ms)
{
    uint32_t t0 = s_ticks;
    while ((uint32_t)(s_ticks - t0) < ms) { __NOP(); }
}
/* ~40 us guard time so the polling slave can service each byte in time. */
static void guard_delay(void)
{
    volatile uint32_t i;
    for (i = 0u; i < 200u; i++) { __NOP(); }
}

/*============================ 3. LD2 and B1 ================================*/
static void led_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOAEN;
    (void)RCC->AHB1ENR;

    GPIOA->MODER   &= ~(3u << (LED_PIN * 2u));
    GPIOA->MODER   |=  (1u << (LED_PIN * 2u));
    GPIOA->OTYPER  &= ~(1u << LED_PIN);
    GPIOA->OSPEEDR &= ~(3u << (LED_PIN * 2u));
    GPIOA->PUPDR   &= ~(3u << (LED_PIN * 2u));
    GPIOA->BSRR     =  (1u << (LED_PIN + 16u));
}
static void led_on (void) { GPIOA->BSRR = (1u << LED_PIN); }
static void led_off(void) { GPIOA->BSRR = (1u << (LED_PIN + 16u)); }

static void button_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;

    GPIOC->MODER &= ~(3u << (BTN_PIN * 2u));
    GPIOC->PUPDR &= ~(3u << (BTN_PIN * 2u));
    GPIOC->PUPDR |=  (1u << (BTN_PIN * 2u));
}
static uint32_t button_down(void)
{
    return ((GPIOC->IDR & (1u << BTN_PIN)) == 0u);
}
static uint8_t button_capture(uint32_t *press_ms)
{
    uint32_t t0, d;

    if (!button_down())  return 0u;
    delay_ms(T_DEBOUNCE_MS);
    if (!button_down())  return 0u;

    t0 = millis();
    while (button_down()) { __NOP(); }
    delay_ms(T_DEBOUNCE_MS);

    d = millis() - t0;
    if (press_ms != 0) { *press_ms = d; }
    return (d >= T_LONG_MS) ? CMD_LONG : CMD_SHORT;
}

/*======================== 4. Optional RGB indicator ========================*/
static void rgb_init(void)
{
#if USE_RGB
    uint32_t p;
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOCEN;
    (void)RCC->AHB1ENR;
    for (p = 0u; p <= 2u; p++) {
        GPIOC->MODER  &= ~(3u << (p * 2u));
        GPIOC->MODER  |=  (1u << (p * 2u));
        GPIOC->OTYPER &= ~(1u << p);
        GPIOC->PUPDR  &= ~(3u << (p * 2u));
    }
#endif
}
static void rgb_set(uint32_t r, uint32_t g, uint32_t b)
{
#if USE_RGB
  #if RGB_COMMON_CATHODE
    GPIOC->BSRR = (r ? (1u << 0) : (1u << 16)) |
                  (g ? (1u << 1) : (1u << 17)) |
                  (b ? (1u << 2) : (1u << 18));
  #else
    GPIOC->BSRR = (r ? (1u << 16) : (1u << 0)) |
                  (g ? (1u << 17) : (1u << 1)) |
                  (b ? (1u << 18) : (1u << 2));
  #endif
#else
    (void)r; (void)g; (void)b;
#endif
}
static void master_indicate(uint32_t ok)
{
    uint32_t i;
    if (ok) {
        rgb_set(0u, 1u, 0u);
        led_on(); delay_ms(250u); led_off();
    } else {
        rgb_set(1u, 0u, 0u);
        for (i = 0u; i < 3u; i++) { led_on(); delay_ms(60u); led_off(); delay_ms(60u); }
    }
    rgb_set(0u, 0u, 0u);
}

/*========================= 5. SPI2 in MASTER mode ==========================*/
static void spi2_master_init(void)
{
    RCC->AHB1ENR |= RCC_AHB1ENR_GPIOBEN;
    RCC->APB1ENR |= RCC_APB1ENR_SPI2EN;
    (void)RCC->APB1ENR;

    /* PB12 = plain GPIO output, used as the chip-select line               */
    GPIOB->MODER   &= ~(3u << (NSS_PIN * 2u));
    GPIOB->MODER   |=  (1u << (NSS_PIN * 2u));
    GPIOB->OTYPER  &= ~(1u << NSS_PIN);
    GPIOB->OSPEEDR |=  (3u << (NSS_PIN * 2u));
    GPIOB->PUPDR   &= ~(3u << (NSS_PIN * 2u));
    GPIOB->BSRR     =  (1u << NSS_PIN);          /* CS idles HIGH           */

    /* PB13 = SCK, PB14 = MISO, PB15 = MOSI, all AF5                        */
    GPIOB->MODER   &= ~((3u << (13u*2u)) | (3u << (14u*2u)) | (3u << (15u*2u)));
    GPIOB->MODER   |=  ((2u << (13u*2u)) | (2u << (14u*2u)) | (2u << (15u*2u)));
    GPIOB->OTYPER  &= ~((1u << 13u) | (1u << 14u) | (1u << 15u));
    GPIOB->OSPEEDR |=  ((3u << (13u*2u)) | (3u << (14u*2u)) | (3u << (15u*2u)));
    GPIOB->PUPDR   &= ~((3u << (13u*2u)) | (3u << (14u*2u)) | (3u << (15u*2u)));
    GPIOB->PUPDR   |=   (1u << (14u*2u));        /* pull-up on MISO         */

    GPIOB->AFR[1] &= ~((0xFu << ((13u-8u)*4u)) | (0xFu << ((14u-8u)*4u)) |
                       (0xFu << ((15u-8u)*4u)));
    GPIOB->AFR[1] |=  ((5u   << ((13u-8u)*4u)) | (5u   << ((14u-8u)*4u)) |
                       (5u   << ((15u-8u)*4u)));

    SPI2->CR1 = 0u;
    SPI2->CR2 = 0u;
    SPI2->CR1 = SPI_CR1_MSTR      |   /* master                             */
                (5u << 3u)        |   /* BR = 101 -> fPCLK1 / 64 = 250 kHz  */
                SPI_CR1_SSM       |   /* software slave management          */
                SPI_CR1_SSI;          /* internal NSS high -> stay master   */
                                      /* CPOL = 0, CPHA = 0, MSB, 8-bit     */
    SPI2->CR1 |= SPI_CR1_SPE;
}
static void cs_low (void) { GPIOB->BSRR = (1u << (NSS_PIN + 16u)); }
static void cs_high(void) { GPIOB->BSRR = (1u << NSS_PIN); }

/* Full-duplex: writing a byte always reads one back. */
static uint8_t spi2_xfer(uint8_t out)
{
    while ((SPI2->SR & SPI_SR_TXE)  == 0u) { }
    *(volatile uint8_t *)&SPI2->DR = out;        /* 8-bit access to DR!     */
    while ((SPI2->SR & SPI_SR_RXNE) == 0u) { }
    return *(volatile uint8_t *)&SPI2->DR;
}

/*================================= main ====================================*/
int main(void)
{
    uint8_t  cmd, ack;
    uint32_t press_ms, ok;

    clock_init_hsi_16mhz();
    systick_init();
    led_init();
    button_init();
    rgb_init();
    spi2_master_init();

    rgb_set(0u, 0u, 1u); led_on(); delay_ms(300u); led_off(); rgb_set(0u,0u,0u);

    for (;;) {
        press_ms = 0u;
        cmd = button_capture(&press_ms);
        if (cmd == 0u) { continue; }

        rgb_set(0u, 0u, 1u);

        cs_low();                       guard_delay();
        (void)spi2_xfer(CMD_SYNC);      guard_delay();
        (void)spi2_xfer(cmd);           guard_delay();
        (void)spi2_xfer((uint8_t)(cmd ^ 0xFFu));
        guard_delay();
        ack = spi2_xfer(0x00u);         /* the slave answers on this byte   */
        guard_delay();
        cs_high();

        rgb_set(0u, 0u, 0u);

        ok = (ack == ACK_BYTE);
        master_indicate(ok);
    }
}
