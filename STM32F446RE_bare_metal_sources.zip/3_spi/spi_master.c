/* EXP 3  SPI2 (mode 0, 250 kHz)  ---  MASTER  ---  NUCLEO-F446RE
 * SPI2 is used because SPI1_SCK is PA5 = LD2.
 * Wiring (STRAIGHT THROUGH, not crossed):
 *          PB12 NSS  (CN10-16) -> slave PB12 (CN10-16)
 *          PB13 SCK  (CN10-30) -> slave PB13 (CN10-30)
 *          PB15 MOSI (CN10-26) -> slave PB15 (CN10-26)
 *          GND       (CN10-20) -> slave GND  (CN10-20)                */

#include "stm32f446xx.h"

static void delay_ms(uint32_t ms)
{
    SysTick->LOAD = 16000 - 1;
    SysTick->VAL  = 0;
    SysTick->CTRL = 5;
    while (ms--) while (!(SysTick->CTRL & (1 << 16)));
    SysTick->CTRL = 0;
}

static void spi_send(uint8_t b)
{
    GPIOB->ODR &= ~(1 << 12);                   /* NSS low  = select    */
    while (!(SPI2->SR & (1 << 1)));             /* TXE                  */
    SPI2->DR = b;
    while (SPI2->SR & (1 << 7));                /* wait BSY = 0         */
    GPIOB->ODR |=  (1 << 12);                   /* NSS high = release   */
}

int main(void)
{
    uint32_t t;

    RCC->AHB1ENR |= (1 << 0) | (1 << 1) | (1 << 2);   /* GPIOA, B, C    */
    RCC->APB1ENR |= (1 << 14);                        /* SPI2           */

    GPIOC->PUPDR  |= (1 << 26);                 /* PC13 pull-up  (B1)   */
    GPIOA->MODER  |= (1 << 10);                 /* PA5 output    (LD2)  */
    GPIOB->MODER  |= (1 << 24);                 /* PB12 output   (NSS)  */
    GPIOB->MODER  |= (2 << 26) | (2 << 30);     /* PB13, PB15 alternate */
    GPIOB->AFR[1] |= (5 << 20) | (5 << 28);     /* AF5 = SPI2           */
    GPIOB->ODR    |= (1 << 12);                 /* NSS idles high       */

    SPI2->CR1 = (1 << 2) | (5 << 3) | (1 << 9) | (1 << 8) | (1 << 6);
    /*          MSTR       BR=/64     SSM        SSI        SPE          */

    while (1) {
        if (GPIOC->IDR & (1 << 13)) continue;

        t = 0;
        while (!(GPIOC->IDR & (1 << 13))) { delay_ms(10); t += 10; }

        spi_send((t >= 1000) ? 'L' : 'S');

        GPIOA->ODR |=  (1 << 5);
        delay_ms(100);
        GPIOA->ODR &= ~(1 << 5);
    }
}
